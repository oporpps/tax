from flask import Blueprint, render_template, request, current_app
from database import get_db
import os

payment_bp = Blueprint("payment", __name__)

payments = []


@payment_bp.route("/search", methods=["GET", "POST"])
def search_payment():

    status = None

    if request.method == "POST":

        firstname = request.form.get("firstname")
        lastname = request.form.get("lastname")

        if firstname == "พงศ์พิสุทธิ์" and lastname == "ศรีชูเลิศ":
            status = "paid"

        elif firstname == "นัทธมน" and lastname == "คูณภาค":
            status = "debt"

        else:
            status = "notfound"

    return render_template("payment_search.html", status=status)


@payment_bp.route("/upload-slip", methods=["POST"])
def upload_slip():

    firstname = request.form.get("firstname")
    lastname = request.form.get("lastname")
    slip = request.files.get("slip")

    amount = 120

    if slip:

        filename = slip.filename
        path = os.path.join(current_app.config["UPLOAD_FOLDER"], filename)
        slip.save(path)

        db = get_db()

        db.execute(
            "INSERT INTO payments (firstname, lastname, amount, slip) VALUES (?, ?, ?, ?)",
            (firstname, lastname, amount, filename)
        )

        db.commit()

        return "อัปโหลดสลิปเรียบร้อย"

    return "ไม่พบไฟล์"