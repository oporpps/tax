import sqlite3

conn = sqlite3.connect("payment.db")

conn.execute("""
CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    firstname TEXT,
    lastname TEXT,
    amount INTEGER,
    slip TEXT,
    status TEXT DEFAULT 'pending'
)
""")

conn.commit()
conn.close()

print("Database created")