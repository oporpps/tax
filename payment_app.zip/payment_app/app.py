from flask import Flask, render_template, request, redirect, session, url_for
from routes.payment_routes import payment_bp
from database import get_db

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "static/slips"
app.secret_key = "porlukkamnakub"

app.register_blueprint(payment_bp, url_prefix="/payment")


@app.route("/")
def index():
    return render_template("home.html")


@app.route("/admin/index")
def admin_index():

    if not session.get("admin"):
        return redirect("/admin/login")

    return render_template("admin/index.html")


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():

    if request.method == "POST":

        username = request.form["username"]
        password = request.form["password"]

        if username == "admin" and password == "1234":
            session["admin"] = True
            return redirect("/admin/index")

    return render_template("admin/login.html")


@app.route("/admin/slip_t")
def slip_t():

    if not session.get("admin"):
        return redirect("/admin/login")

    db = get_db()

    search = request.args.get("search")

    if search:
        payments = db.execute(
            "SELECT * FROM payments WHERE firstname LIKE ? OR lastname LIKE ? ORDER BY id DESC",
            ('%' + search + '%', '%' + search + '%')
        ).fetchall()
    else:
        payments = db.execute(
            "SELECT * FROM payments ORDER BY id DESC"
        ).fetchall()

    return render_template("admin/slip_t.html", payments=payments)


# =============================
# approve payment
# =============================

@app.route("/admin/approve/<int:id>")
def approve_payment(id):

    if not session.get("admin"):
        return redirect("/admin/login")

    db = get_db()

    db.execute(
        "UPDATE payments SET status='approved' WHERE id=?",
        (id,)
    )

    db.commit()

    return redirect("/admin/slip_t")


# =============================
# reject payment
# =============================

@app.route("/admin/reject/<int:id>")
def reject_payment(id):

    if not session.get("admin"):
        return redirect("/admin/login")

    db = get_db()

    db.execute(
        "UPDATE payments SET status='rejected' WHERE id=?",
        (id,)
    )

    db.commit()

    return redirect("/admin/slip_t")


@app.route("/admin/logout")
def admin_logout():
    session.clear()
    return redirect("/")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)